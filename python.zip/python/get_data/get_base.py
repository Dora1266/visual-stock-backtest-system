import akshare as ak
from db import read_specific_columns_from_mysql, replace_df_mysql
def fetch_and_push_stock(stock_codes, db_name, start_date, end_date, sio):
    for stock_code in stock_codes:
        print(f'处理股票代码: {stock_code}')
        try:
            existing_data = read_specific_columns_from_mysql(db_name, stock_code, ['日期'])
            if not existing_data.empty:
                max_date = existing_data['日期'].max()
            else:
                max_date = start_date
        except Exception as e:
            print(f"读取数据库时发生错误: {e}")
            print(f"设置为最早日期来开始抓取: {start_date}")
            max_date = start_date

        stock_df = ak.stock_zh_a_hist(symbol=stock_code, period="daily", start_date=max_date, end_date=end_date, adjust="")
        stock_qfq_df = ak.stock_zh_a_hist(symbol=stock_code, period="daily", start_date=max_date, end_date=end_date, adjust="qfq")
        stock_hfq_df = ak.stock_zh_a_hist(symbol=stock_code, period="daily", start_date=max_date, end_date=end_date, adjust="hfq")

        stock_hfq_df.columns = [f'{col}_后复权' if col not in ['日期', '股票代码'] else col for col in stock_hfq_df.columns]
        merged_df = stock_df.merge(stock_qfq_df, on=['日期', '股票代码'], suffixes=('_不复权', '_前复权'))
        merged_df = merged_df.merge(stock_hfq_df, on=['日期', '股票代码'])

        merged_df = merged_df.drop(columns=['股票代码'])

        replace_df_mysql(merged_df, db_name=db_name, table_name=stock_code)

        sio.emit('stock_update', {'stock_code': stock_code, 'status': 'completed'})

        print(f'{stock_code} 处理完成')

def get_stock_data(stock_list, db_name, start_date, end_date, sio):
    for stock_code in stock_list:
        try:
            fetch_and_push_stock(stock_code, db_name, start_date, end_date, sio)
        except Exception as exc:
            print(f'{stock_code} 发生异常: {exc}')
            sio.emit('stock_update', {'stock_code': stock_code, 'status': 'error', 'error': str(exc)})
