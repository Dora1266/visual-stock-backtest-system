import akshare as ak
from db.stock_operations import read_last_row_mysql, add_df_mysql
from db.operations import read_matching_column
from data_processor.formatted_date import formatted_date
import pandas as pd
from datetime import timedelta

def get_db_and_recent_date(stock_code):
    system_db_name = 'system'
    system_table_name = "system"
    system_match_column = "config_name"
    db_name = read_matching_column(system_db_name, system_table_name, system_match_column, 'china_db_name')
    a = read_last_row_mysql([stock_code], db_name, ['日期'], '日期')
    if a.empty:
        raise ValueError(f"未找到股票 {stock_code} 的日期数据")

    recent_date = formatted_date(f"{a['日期'].iloc[0]}")
    start_date = (pd.to_datetime(recent_date) + timedelta(days=1)).strftime('%Y%m%d')
    return db_name, start_date

def get_stock_data_adjusted(stock_code, start_date, end_date, adjust):
    stock_data = ak.stock_zh_a_hist(
        symbol=stock_code,
        period="daily",
        start_date=start_date,
        end_date=end_date,
        adjust=adjust
    )
    if stock_data is None or stock_data.empty:
        return None
    if adjust == "hfq":
        stock_data.columns = [f'{col}_后复权' if col not in ['日期', '股票代码'] else col for col in stock_data.columns]
    return stock_data

def fetch_stock_data(stock_codes, socketio):
    if not isinstance(stock_codes, list):
        stock_codes = [stock_codes]
    stock_results = {}
    end_date = "20990909"
    adjust_types = ["", "qfq", "hfq"]

    for stock_code in stock_codes:
        try:
            db_name, start_date = get_db_and_recent_date(stock_code)
        except ValueError as e:
            print(e)
            continue

        stock_fetched = False

        for adjust in adjust_types:
            try:
                stock_data = get_stock_data_adjusted(stock_code, start_date, end_date, adjust)

                if stock_data is not None and not stock_data.empty:
                    stock_results[(stock_code, adjust)] = stock_data
                    stock_fetched = True
                else:
                    print(f"{stock_code} 在 {adjust} 调整选项下没有新数据")
            except Exception as exc:
                print(f"获取 {stock_code} 数据失败: {exc}")

        if not stock_fetched:
            print(f"{stock_code} 没有新数据需要更新")
            socketio.emit('stock_update', {'stock_code': stock_code, 'status': 'no_update_needed'})
            continue

        if not all((stock_code, adjust) in stock_results for adjust in adjust_types):
            print(f"{stock_code} 未能获取所有类型的调整数据")
            continue
        merged_df = stock_results[(stock_code, "")].merge(stock_results[(stock_code, "qfq")], on=['日期', '股票代码'],
                                                         suffixes=('_不复权', '_前复权'))
        merged_df = merged_df.merge(stock_results[(stock_code, "hfq")], on=['日期', '股票代码'])
        merged_df = merged_df.drop(columns=['股票代码'])
        add_df_mysql(merged_df, db_name=db_name, table_name=stock_code)
        socketio.emit('stock_update', {'stock_code': stock_code, 'status': 'completed'})
