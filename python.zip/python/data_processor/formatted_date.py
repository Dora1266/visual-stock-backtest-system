
def formatted_date(date):
    formatted_date = date.replace("-", "")
    return formatted_date
