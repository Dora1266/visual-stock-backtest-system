import pandas as pd

from datetime import datetime


def df2c(df):
    # 将每一列转为字典，键为列名，值为列数据
    columns = {}
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            # 如果是日期类型，显式转换为 datetime.date() 的形式
            columns[col] = [datetime.strptime(str(date), '%Y-%m-%d %H:%M:%S').date() for date in df[col]]
        else:
            columns[col] = df[col].tolist()

    print(columns)

    # 返回字典格式响应
    return columns


